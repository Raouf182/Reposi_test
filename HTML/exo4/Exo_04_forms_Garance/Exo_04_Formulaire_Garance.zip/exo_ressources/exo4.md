---
theme: gaia
_class: lead
paginate: false
backgroundColor: #fff
---

# **Exercice 4 - HTML**

Construisez une nouvelle page "contact.html"
En reprenant le travail de l'exercice 3, rajoutez la page Contact et son formulaire:

- La page Contact est accessible depuis le lien "Me contacter"

---
## **Page principale**

![exo4_mainpage](image.png)

---
## **Page contact**

![exo4_contactpage](image-1.png)

---