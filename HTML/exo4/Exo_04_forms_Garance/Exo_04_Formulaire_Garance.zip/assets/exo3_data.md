**Texte:**

*Second article*

Salut à tous ! Je suis super excitée de vous annoncer une grande nouvelle. Après des semaines de préparation, j'ai finalement ouvert ma propre chaîne Twitch dédiée à l'univers informatique. 🎮💻

Sur ma chaîne, nous allons plonger dans le monde fascinant de la programmation, des dernières technologies et des discussions en direct sur les sujets brûlants de l'industrie. Imaginez des sessions de codage interactives, des astuces pour optimiser votre workflow de développement, et bien sûr, des moments de détente où nous pourrons discuter librement de nos passions communes.

Rejoignez-moi en direct pour des streams hebdomadaires, des sessions Q&R, et des événements spéciaux où nous pourrons échanger des idées et construire une communauté solide de nerds modernes. C'est le moment idéal pour partager nos connaissances, apprendre ensemble et se lancer dans des aventures numériques épiques.

N'oubliez pas de vous abonner à ma chaîne pour être informé(e) des prochains streams et pour ne rien manquer de cette nouvelle aventure palpitante. Vous trouverez mes horaires de diffusion plus bas dans la page. Merci à tous pour votre soutien continu, et j'ai hâte de vous retrouver sur Twitch pour des heures incroyables de code, de rires et de découvertes. Restez connectés ! 🚀👩‍💻

*Premier article*

Salut les amis ! Aujourd'hui, je suis super excitée de partager avec vous ma découverte récente : le HTML. Oui, je sais, ça fait un moment que ça existe, mais je me suis enfin lancée dedans ! C'est comme si j'avais trouvé un trésor caché dans le monde numérique.
Alors, le HTML, c'est un peu comme la structure de base de tout site web.
Vous savez, c'est le langage qui donne vie à toutes ces pages magnifiques que nous aimons parcourir. Les balises sont un peu comme les ingrédients d'une recette : elles indiquent où doit aller le titre, l'image, le texte, et tout ce qui rend un site captivant.
Mais pour maîtriser ce langage, trois qualités sont essentielles:
    De la patience
    Une bonne mémoire
    Maîtriser sa consommation de caféine
Alors, pour tous mes followers qui souhaitent donner une touche personnelle à leur site, le HTML est une compétence incontournable. Croyez-moi, je suis conquise, et je suis sûre que vous le serez aussi.
Allez, on se lance dans cette aventure numérique ensemble !

**Liens**

Google: https://www.google.com/
W3C: https://www.w3.org/
MDN: https://developer.mozilla.org/fr/